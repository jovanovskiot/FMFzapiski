import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

def model_laser(y, t, alfa, beta, B1, B2, R):
    """
    Definicija sistema diferencialnih enačb za model laserja.
    f: število fotonov
    a: število vzbujenih atomov
    """
    f, a = y

    df_dt = -alfa * f + B1 * a * f
    da_dt = -beta * a - B2 * a * f + R

    return [df_dt, da_dt]

# --- 1. del: Analiza stacionarnega stanja ---

# Definicija parametrov modela
alfa = 0.5
beta = 0.1
B1 = 0.01
B2 = 0.008

# Izračun laserskega praga
R_prag = beta * alfa / B1
print(f"Izračunan laserski prag je pri R_prag = {R_prag:.2f}")

# Priprava niza vrednosti za moč črpanja R
R_values = np.linspace(0, 2 * R_prag, 200)

# Priprava seznamov za shranjevanje stacionarnih vrednosti
f_stationary = []
a_stationary = []

# Zanka za izračun stacionarnih stanj glede na R
for R in R_values:
    if R < R_prag:
        # Pod pragom: laser ne deluje
        f = 0
        a = R / beta
    else:
        # Nad pragom: laser deluje
        f = (R - R_prag) / (B2 * (alfa / B1))
        a = alfa / B1
    
    f_stationary.append(f)
    a_stationary.append(a)

# --- Izris grafa odvisnosti stacionarnega stanja od R ---

# Ustvarimo sliko z dvema podgrafoma, ki si delita x-os
fig, ax = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Zgornji graf: Število fotonov f(R)
ax[0].plot(R_values, f_stationary, 'r-', linewidth=2, label='Število fotonov (f)')
ax[0].set_ylabel('Število fotonov [brezdim.]')
ax[0].set_title('Odvisnost stacionarnega stanja laserja od moči črpanja')
ax[0].grid(True)
ax[0].axvline(R_prag, color='gray', linestyle='--', label=f'Laserski prag (R={R_prag:.1f})')
ax[0].legend()

# Spodnji graf: Število vzbujenih atomov a(R)
ax[1].plot(R_values, a_stationary, 'b-', linewidth=2, label='Št. vzbujenih atomov (a)')
ax[1].set_xlabel('Moč črpanja (R) [brezdim.]')
ax[1].set_ylabel('Št. vzbujenih atomov [brezdim.]')
ax[1].grid(True)
ax[1].axvline(R_prag, color='gray', linestyle='--')
ax[1].legend()

# Shranimo graf
plt.savefig('laser_stacionarno_stanje.pdf')
plt.close()

print("Graf stacionarnega stanja shranjen kot laser_stacionarno_stanje.pdf")

# --- 2. del: Analiza faznega portreta in nihanj ---

# Parametri ostanejo enaki
# Testne vrednosti za R (nad pragom)
R_test_values = [R_prag * 1.1, R_prag * 1.5, R_prag * 2.0]
colors = ['blue', 'green', 'purple']

# Časovna mreža za simulacijo
t_simulation = np.linspace(0, 200, 2000)

# Začetni pogoj ("vklop" laserja)
y0_start = [0.1, 0]

# Priprava platna za risanje
plt.figure(figsize=(10, 8))

# Zanka čez testne vrednosti R za izris faznih portretov
for i, R in enumerate(R_test_values):
    # Reševanje sistema
    solution_laser = odeint(model_laser, y0_start, t_simulation, args=(alfa, beta, B1, B2, R))
    
    # Pridobitev poti za f in a
    f_path = solution_laser[:, 0]
    a_path = solution_laser[:, 1]
    
    # Izris trajektorije
    plt.plot(f_path, a_path, color=colors[i], label=f'Trajektorija pri R = {R:.2f}')
    
    # Izračun in izris ustrezne stacionarne točke
    f_stac_R = (R - R_prag) / (B2 * (alfa / B1))
    a_stac_R = alfa / B1
    plt.plot(f_stac_R, a_stac_R, 'o', color=colors[i], markersize=12, 
             markeredgecolor='black', label=f'Stacionarna točka pri R = {R:.2f}')

# Dodajanje naslova in oznak
plt.title('Fazni portret za model laserja pri različnih močeh črpanja')
plt.xlabel('Število fotonov (f) [brezdim.]')
plt.ylabel('Število vzbujenih atomov (a) [brezdim.]')
plt.legend()
plt.grid(True)
plt.xlim(left=0) # Poskrbimo, da so vrednosti na grafu fizikalno smiselne
plt.ylim(bottom=0)

# Shranjevanje grafa
plt.savefig('laser_fazni_portret.pdf')
plt.close()

print("\nFazni portret laserja shranjen kot laser_fazni_portret.pdf")