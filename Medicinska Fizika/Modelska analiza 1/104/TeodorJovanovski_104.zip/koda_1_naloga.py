import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.signal import find_peaks

# =============================================================================
# DEFINICIJE MODELOV
# =============================================================================

def model(y, t, alpha, beta):
    """
    Osnovni SIR model epidemije.
    y: [D, B, I] -> Dovzetni, Bolni, Imuni
    t: čas
    alpha: stopnja prenosa okužbe
    beta: stopnja okrevanja
    """
    D, B, I = y
    
    dD_dt = -alpha * D * B
    dB_dt = alpha * D * B - beta * B
    dI_dt = beta * B
    
    return [dD_dt, dB_dt, dI_dt]

def model_stages(y, t, alpha, beta, sigma):
    """
    SEIR model z ločeno fazo inkubacije (izpostavljeni).
    y: [D, B1, B2, I] -> Dovzetni, Izpostavljeni, Kužni, Imuni
    sigma: stopnja prehoda iz izpostavljenih v kužne (1/inkubacijska doba)
    """
    D, B1, B2, I = y

    dD_dt = -alpha * D * B2
    dB1_dt = alpha * D * B2 - sigma * B1
    dB2_dt = sigma * B1 - beta * B2
    dI_dt = beta * B2

    return [dD_dt, dB1_dt, dB2_dt, dI_dt]

def model_sirs(y, t, alpha, beta, delta):
    """
    SIRS model z izgubo imunosti.
    y: [D, B, I] -> Dovzetni, Bolni, Imuni
    delta: stopnja izgube imunosti (1/čas trajanja imunosti)
    """
    D, B, I = y

    dD_dt = -alpha * D * B + delta * I  # Ljudje iz I se vračajo v D
    dB_dt = alpha * D * B - beta * B
    dI_dt = beta * B - delta * I      # Ljudje zapuščajo I

    return [dD_dt, dB_dt, dI_dt]

# =============================================================================
# POMOŽNA FUNKCIJA ZA IZRIS POSAMEZNIH SIMULACIJ
# =============================================================================

def run_and_plot_simulation(vaccination_percentage):
    """Zažene eno SIR simulacijo in shrani graf."""
    # Začetni pogoji
    B0 = 1
    I0 = N * vaccination_percentage / 100
    D0 = N - B0 - I0
    y0 = [D0, B0, I0]

    # Parametri modela
    alpha = 0.0004
    beta = 0.04 

    # Časovna mreža
    t = np.linspace(0, 200, 1000) # Podaljšan čas za boljši prikaz

    # Reševanje diferencialnih enačb
    solution = odeint(model, y0, t, args=(alpha, beta))

# --- Izris rezultatov (z večjimi pisavami) ---
    plt.figure(figsize=(10, 8)) # Rahlo večja slika za boljšo resolucijo

    # Uporabimo debelejše črte za boljšo vidljivost
    plt.plot(t, solution[:, 0], 'b', label='Dovzetni (D)', linewidth=2.5)
    plt.plot(t, solution[:, 1], 'r', label='Okuženi (B)', linewidth=2.5)
    plt.plot(t, solution[:, 2], 'g', label='Imuni (I)', linewidth=2.5)

    # Nastavitev velikosti pisav za vse elemente
    plt.xlabel('Čas (dnevi)', fontsize=16)
    plt.ylabel('Število oseb', fontsize=16)
    plt.title(f'Model epidemije (SIR) pri {vaccination_percentage}% cepljenosti', fontsize=20)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.legend(fontsize=14)
    plt.grid(True)

    # Iskanje in izris vrha epidemije (z večjo pisavo)
    peak_infected_value = solution[:, 1].max()
    if peak_infected_value > 1.1:
        peak_index = np.argmax(solution[:, 1])
        peak_time = t[peak_index]
        peak_text = f'Vrh: {peak_infected_value:.0f} okuženih'
        plt.text(peak_time*1.1, peak_infected_value * 1.05, peak_text, fontsize=14, horizontalalignment='center')

    # Shranjevanje grafa
    ime_datoteke = f'krivulja_epidemije_{vaccination_percentage}_odstotkov.pdf'
    plt.savefig(ime_datoteke, bbox_inches='tight') # bbox_inches='tight' lepo oreže sliko
    plt.close()
    print(f"Graf shranjen kot: {ime_datoteke}")

# =============================================================================
# GLAVNA SKRIPTA
# =============================================================================

# Skupno število prebivalcev
N = 1000

# --- 1. DEL: SIMULACIJA POSAMEZNIH SCENARIJEV (SIR) ---
print("--- Začenjam izris posameznih scenarijev cepljenja ---")
run_and_plot_simulation(0)
run_and_plot_simulation(25)
run_and_plot_simulation(50)
run_and_plot_simulation(75)

# --- 2. DEL: ANALIZA UČINKOVITOSTI CEPLJENJA ---
print("\n--- Začenjam analizo učinkovitosti cepljenja ---")

# Analiza od 0% do 90%
vaccination_levels_0_90 = np.arange(0, 91, 10)
peak_infections_0_90 = []
for percentage in vaccination_levels_0_90:
    I0 = N * (percentage / 100.0)
    B0 = 1
    D0 = N - I0 - B0
    solution = odeint(model, [D0, B0, I0], np.linspace(0, 200, 1000), args=(0.0004, 0.04))
    peak_infections_0_90.append(solution[:, 1].max())

plt.figure(figsize=(10, 6))
plt.plot(vaccination_levels_0_90, peak_infections_0_90, 'bo-', linewidth=2)
plt.title('Vpliv cepljenja na vrh epidemije (0-90%)')
plt.xlabel('Delež cepljenih (%)')
plt.ylabel('Maksimalno število okuženih')
plt.grid(True)
plt.savefig('ucinkovitost_cepljenja_0-90.pdf')
plt.close()
print("Graf analize (0-90%) shranjen kot: ucinkovitost_cepljenja_0-90.pdf")

# Analiza od 80% do 99% (kot v vaši kodi)
vaccination_levels_80_99 = np.linspace(80, 99, 40)
peak_infections_80_99 = []
for percentage in vaccination_levels_80_99:
    I0 = N * (percentage / 100.0)
    B0 = 1
    D0 = N - I0 - B0
    solution = odeint(model, [D0, B0, I0], np.linspace(0, 200, 1000), args=(0.0004, 0.04))
    peak_infections_80_99.append(solution[:, 1].max())

plt.figure(figsize=(10, 6))
plt.plot(vaccination_levels_80_99, peak_infections_80_99, 'bo-', linewidth=2)
plt.title('Vpliv cepljenja na vrh epidemije (območje čredne imunosti)')
plt.xlabel('Delež cepljenih (%)')
plt.ylabel('Maksimalno število okuženih')
plt.grid(True)
plt.savefig('ucinkovitost_cepljenja_80-99.pdf')
plt.close()
print("Graf analize (80-99%) shranjen kot: ucinkovitost_cepljenja_80-99.pdf")

# --- 3. DEL: PRIMERJAVA Z MODELOM S FAZAMI OKUŽBE (SEIR) ---
print("\n--- Začenjam primerjavo SIR in SEIR modelov ---")
# Parametri
alpha = 0.0004
beta = 0.04 
sigma = 1/5 # Inkubacijska doba 5 dni
t = np.linspace(0, 200, 1000)

# Rešitev za SEIR model
y0_stages = [N - 1, 1, 0, 0] # D0, B1_0, B2_0, I0
solution_stages = odeint(model_stages, y0_stages, t, args=(alpha, beta, sigma))

# Rešitev za SIR model za primerjavo
y0_simple = [N - 1, 1, 0] # D0, B0, I0
solution_simple = odeint(model, y0_simple, t, args=(alpha, beta))

# Izris primerjalnega grafa
plt.figure(figsize=(12, 7))
plt.plot(t, solution_simple[:, 1], 'r--', linewidth=2, label='Okuženi (Enostavni SIR model)')
plt.plot(t, solution_stages[:, 2], 'r-', linewidth=2, label='Kužni B2 (Model s fazami)')
plt.plot(t, solution_stages[:, 1], 'y:', linewidth=2, label='Izpostavljeni B1 (Model s fazami)')
plt.title('Primerjava enostavnega in večfaznega modela epidemije')
plt.xlabel('Čas (dnevi)')
plt.ylabel('Število oseb')
plt.legend()
plt.grid(True)
plt.savefig('primerjava_modelov_s_fazami.pdf')
plt.close()
print("Primerjalni graf SIR vs SEIR shranjen kot: primerjava_modelov_s_fazami.pdf")

# --- DODATNA NALOGA: SIRS model s sezonsko kužnostjo ---

print("\n--- Začenjam simulacijo SIRS modela s sezonsko kužnostjo ---")

def model_sirs_seasonal(y, t, alpha_avg, amplitude, beta, delta):
    # ... (definicija modela ostane nespremenjena)
    D, B, I = y
    alpha_seasonal = alpha_avg * (1 + amplitude * np.cos(2 * np.pi * t / 365))
    dD_dt = -alpha_seasonal * D * B + delta * I
    dB_dt = alpha_seasonal * D * B - beta * B
    dI_dt = beta * B - delta * I
    return [dD_dt, dB_dt, dI_dt]

# Parametri (N je definiran v prejšnjem delu skripte)
N = 1000 # Dodajmo definicijo N za primer, če se skripta poganja samostojno
alpha_avg = 0.0004
amplitude = 0.3
beta = 0.05
delta = 1/365

# Dolgo časovno obdobje (5 let)
t_seasonal = np.linspace(0, 365 * 5, 5000) # Povečamo število točk za natančnost
y0_seasonal = [N * 0.8, 1, N * 0.2]

# Reševanje modela
solution_seasonal = odeint(model_sirs_seasonal, y0_seasonal, t_seasonal, 
                           args=(alpha_avg, amplitude, beta, delta))

# --- Grafični del ostane nespremenjen ---
# (koda za izris grafa sirs_sezonski_valovi.pdf)
fig, ax1 = plt.subplots(figsize=(15, 8))
ax1.plot(t_seasonal, solution_seasonal[:, 1], 'r-', linewidth=2, label='Okuženi (B)')
ax1.set_xlabel('Čas (dnevi)')
ax1.set_ylabel('Število okuženih oseb', color='r')
ax1.tick_params(axis='y', labelcolor='r')
ax1.grid(True, linestyle='--', alpha=0.6)
ax2 = ax1.twinx()
alpha_values = alpha_avg * (1 + amplitude * np.cos(2 * np.pi * t_seasonal / 365))
ax2.plot(t_seasonal, alpha_values, 'k:', linewidth=2, label='Sezonska kužnost (α(t))')
ax2.set_ylabel('Stopnja prenosa (α)', color='k')
ax2.tick_params(axis='y', labelcolor='k')
fig.suptitle('Simulacija sezonske bolezni (SIRS z α(t))', fontsize=16)
fig.legend(loc="upper right", bbox_to_anchor=(0.9, 0.9))
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig('sirs_sezonski_valovi.pdf')
plt.close()
print("Graf za sezonski SIRS model shranjen kot: sirs_sezonski_valovi.pdf")

# =============================================================================
# NOV DEL: Analiza časovnega zamika vrhov (brez grafa)
# =============================================================================

print("\n--- Analiza časovnega zamika vrhov okužb ---")

# Najdemo indekse vseh vrhov v številu okuženih
# 'height=50' pomeni, da ignoriramo manjše "hribčke" pod 50 okuženih
peak_indices, _ = find_peaks(solution_seasonal[:, 1], height=50)

# Pripravimo si imena mesecev za lažjo interpretacijo
month_names = ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Avg", "Sep", "Okt", "Nov", "Dec"]
month_days = np.cumsum([0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30])

# Zanka čez najdene vrhove (ignoriramo prvega, ker je lahko posledica začetnih pogojev)
lags = []
for i, peak_index in enumerate(peak_indices[1:]):
    # Dan v simulaciji, ko je dosežen vrh
    peak_day_simulation = t_seasonal[peak_index]
    
    # Dan v letu (med 0 in 364)
    peak_day_of_year = peak_day_simulation % 365
    
    # Najdemo ime meseca
    month_index = np.where(month_days <= peak_day_of_year)[0][-1]
    peak_month = month_names[month_index]
    
    # Najbližji vrh kužnosti (zgodil se bo na dan 365, 730, ...)
    # To je vrh zime (okoli 1. januarja)
    year = np.floor(peak_day_simulation / 365)
    peak_alpha_day = (year + 1) * 365
    
    # Izračunamo zamik v dnevih
    lag_days = peak_alpha_day - peak_day_simulation
    lags.append(lag_days)
    
    print(f"Leto {i+2}: Vrh okužb dosežen na dan {peak_day_simulation:.0f} simulacije.")
    print(f"  -> To je {peak_day_of_year:.0f}. dan v letu (mesec: {peak_month}).")
    print(f"  -> Vrh kužnosti (zima) je na dan {peak_alpha_day:.0f}.")
    print(f"  -> Vrh okužb se zgodi {lag_days:.0f} dni PRED vrhuncem kužnosti.")

# Izračunamo povprečen zamik
average_lag = np.mean(lags)
print(f"\nPovprečno pride do vrha okužb {average_lag:.0f} dni pred vrhuncem zime.")