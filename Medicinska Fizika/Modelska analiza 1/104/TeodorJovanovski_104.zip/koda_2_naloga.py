import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint


def model_lotka_volterra(y, tau, p):
    z, l = y
    dz_dtau = p * z * (1 - l)
    dl_dtau = -(1/p) * l * (1 - z)

    return[dz_dtau, dl_dtau]

p = 1.0
tau = np.linspace(0, 20, 1000)
y0 = [1.5, 1.0] #zacetni pogoj

solution_lv = odeint(model_lotka_volterra, y0, tau, args=(p,))

# --- Izris faznega portreta ---
plt.figure(figsize=(8, 8))

# Izris trajektorije
plt.plot(solution_lv[:, 0], solution_lv[:, 1], 'b-', label=f'Začetni pogoj: z={y0[0]}, l={y0[1]}')

# Izris stacionarnih točk
plt.plot(0, 0, 'ro', markersize=10, label='Stacionarna točka (Izumrtje)')
plt.plot(1, 1, 'go', markersize=10, label='Stacionarna točka (Sožitje)')

# Dodajanje puščic za prikaz smeri gibanja (neobvezno, a koristno)
# Vzamemo nekaj točk na trajektoriji in narišemo puščico od ene do druge
# To pokaže, ali se sistem giblje v smeri urinega kazalca ali obratno
indices = [0, 20, 100, 300]
for i in indices:
    z1, l1 = solution_lv[i]
    z2, l2 = solution_lv[i+10] # točka malo kasneje v času
    plt.arrow(z1, l1, z2-z1, l2-l1, head_width=0.05, color='gray')


# Dodajanje naslova in oznak
plt.title(f'Fazni portret za Lotka-Volterra model (p={p})')
plt.xlabel('Populacija zajcev (z) [brezdimenzijsko]')
plt.ylabel('Populacija lisic (l) [brezdimenzijsko]')
plt.legend()
plt.grid(True)
plt.axis('equal') # Zagotovi, da so osi enako skalirane, da krogi izgledajo kot krogi

# Shranjevanje grafa
plt.savefig('faza_ena_trajektorija.pdf')
plt.close()

print("Graf faznega portreta shranjen kot faza_ena_trajektorija.pdf")

# Seznam različnih začetnih pogojev
zacetni_pogoji = [[1.5, 1.0], [2.0, 1.0], [2.5, 1.0], [1.0, 1.5], [1.0, 2.0], [0.5, 0.7]]

# Priprava platna za risanje
plt.figure(figsize=(8, 8))

# Zanka čez vse začetne pogoje
for y0 in zacetni_pogoji:
    # Reševanje sistema za trenutni začetni pogoj
    solution_lv = odeint(model_lotka_volterra, y0, tau, args=(p,))
    
    # Izris trajektorije na isti graf
    plt.plot(solution_lv[:, 0], solution_lv[:, 1], label=f'z₀={y0[0]}, l₀={y0[1]}')

# --- Po končani zanki dodamo še ostale elemente grafa ---

# Izris stacionarnih točk
plt.plot(0, 0, 'ko', markersize=10, label='Stacionarna točka (Izumrtje)')
plt.plot(1, 1, 'ro', markersize=10, label='Stacionarna točka (Sožitje)')

# Dodajanje naslova in oznak
plt.title(f'Fazni portret za Lotka-Volterra model (p={p})')
plt.xlabel('Populacija zajcev (z) [brezdimenzijsko]')
plt.ylabel('Populacija lisic (l) [brezdimenzijsko]')

# Nastavitev mej grafa, da bo center lepo viden
plt.xlim(0, 3)
plt.ylim(0, 3)
plt.legend()
plt.grid(True)
plt.axis('equal')

# Shranjevanje in zapiranje grafa
plt.savefig('fazni_portret_celota.pdf')
plt.close()

print("Celoten fazni portret shranjen kot fazni_portret_celota.pdf")

# Obhodne dobe

z0_vrednosti = [1.1, 1.3, 1.5, 1.7, 1.9, 2.1]

obhodne_dobe = []
tau_perioda = np.linspace(0, 50, 2000)

for z0 in z0_vrednosti:
    y0 = [z0, 1.0]
    solution_lv = odeint(model_lotka_volterra, y0, tau_perioda, args=(p,))

    # Najdi indekse, kjer l prečka 1.0
    prehodi_indeksi = np.where(np.diff(np.sign(solution_lv[:, 1] - 1.0)))[0]

    if len(prehodi_indeksi) >= 2:
        indeks_konca_cikla = prehodi_indeksi[1]
        perioda = tau_perioda[indeks_konca_cikla]
        obhodne_dobe.append(perioda)
    else:
        obhodne_dobe.append(np.nan)

if not any(np.isnan(obhodne_dobe)):
    plt.figure(figsize=(10, 6))

    # Izris podatkovnih točk in povezovalne črte
    plt.plot(z0_vrednosti, obhodne_dobe, 'ro-', linewidth=2, markersize=8)
    
    # Dodajanje naslova in oznak
    plt.title('Odvisnost obhodne dobe od začetnega odklona populacije zajcev')
    plt.xlabel('Začetna populacija zajcev (z₀) [pri l₀=1]')
    plt.ylabel('Obhodna doba (Perioda T) [v enotah τ]')
    plt.grid(True)
    
    # Dodajanje opombe o stacionarni točki
    # Teoretično bi bila obhodna doba v bližini centra neskončna, praktično pa naš model tam niha zelo počasi.
    # Za z0=1 je perioda nedefinirana.
    plt.axvline(1.0, color='gray', linestyle='--', label='Ravnovesna točka (z=1)')
    plt.legend()

    # Shranjevanje grafa
    plt.savefig('obhodne_dobe_odvisnost.pdf')
    plt.close()

    print("\nGraf odvisnosti obhodnih dob shranjen kot obhodne_dobe_odvisnost.pdf")
    
    # Izpis rezultatov v konzolo za lažji pregled
    print("\n--- Rezultati analize obhodnih dob ---")
    for i in range(len(z0_vrednosti)):
        print(f"Začetni pogoj z₀ = {z0_vrednosti[i]:.1f}  ->  Perioda T = {obhodne_dobe[i]:.4f}")
else:
    print("\nPrišlo je do napake pri računanju period. Graf ni bil ustvarjen.")